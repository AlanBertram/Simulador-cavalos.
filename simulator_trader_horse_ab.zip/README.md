
# Simulator Trader Horse AB

Este é um simulador de corridas de cavalos que utiliza probabilidades baseadas em odds para simular milhares de corridas, gerar estatísticas e visualizações com Plotly, e permitir o download dos resultados.

## Como usar no Streamlit Cloud

1. Faça login em https://streamlit.io/cloud
2. Conecte seu GitHub e selecione este repositório
3. Clique em "Deploy"

Pronto! Seu simulador estará online.
